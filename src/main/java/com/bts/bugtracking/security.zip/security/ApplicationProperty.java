package com.bts.bugtracking.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

public class ApplicationProperty {

	@Autowired
	private Environment environment;

	public String getTokenSecret() {
		System.out.println("getTokenSecret called token.secret is " + environment.getProperty("token.secret"));
		return environment.getProperty("token.secret");
	}

	public String getExpritionTime() {
		System.out.println("getExpritionTime called");
		return environment.getProperty("token.exparation.in.millis");
	}

	public String getEmailVerificationTokenExpritionTime() {
		System.out.println("getEmailVerificationTokenExpritionTime called");
		return environment.getProperty("email.verification.token.exparation.in.millis");
	}

	public String getTokenPrefix() {
		System.out.println("getTokenPrefix called");

		return environment.getProperty("token.prefix");
	}

	public String getSignupUrl() {
		System.out.println("getTokenPrefix called");

		return environment.getProperty("signup.url");
	}

	public String getHeaderString() {
		System.out.println("getHeaderString called");

		return environment.getProperty("header.string");
	}

}
